# IPTV Player (Phase 1)
Android phone + Android TV project (Kotlin, Compose, Media3, Room, encrypted credentials).

## Build the APK without a PC
1. Create a free GitHub repo, upload this folder's contents.
2. Open the Actions tab -> "Build APK" -> run it (it also runs on every push).
3. When it finishes, download the `IPTV-debug-apk` artifact and install the APK.

## Build with Android Studio
Open this folder, let Gradle sync, press Run.

## Included
Home, Add Subscription (Xtream / M3U URL+file / Stalker MAC / Single URL, validated),
Switch Subscription, Live TV list + search, ExoPlayer, Arabic/English, D-pad focus glow.
Next phase: Movies, Series, EPG, Favorites, Downloads, Settings, Stalker playback.


## Web Search (v0.7)
- Searches external catalogues only; it never searches the active IPTV subscription.
- Series, seasons and episode numbering use the public TVmaze API (CC BY-SA).
- Movie metadata and artwork use Apple Search API.
- The last search term is retained when navigating back.
- Each movie and each series episode has a separate persistent source list. No viewing links are inserted automatically; users add source URLs themselves.
- Saved direct media URLs can open in Rare Player; website URLs open in the in-app browser. Protected streams, DRM, or paywalls are not bypassed.
- The MovieBox archive was inspected for high-level architecture/domain clues only. Its private backend endpoints and protected playback are not reused.
- Source lists are stored locally in app preferences and are not uploaded to a server.


package com.iptv.player.data

import android.content.Context
import android.net.Uri
import androidx.room.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

@Entity data class Sub(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val type: String, val url: String,
    val user: String = "", val expTs: Long = 0,
    /** Live stream format for Xtream: "" = default (HLS), "ts" or "m3u8". */
    @ColumnInfo(defaultValue = "''") val fmt: String = ""
)
fun Sub.expired() = expTs > 0 && expTs * 1000 < System.currentTimeMillis()

@Dao interface SubDao {
    @Query("SELECT * FROM Sub ORDER BY id") fun all(): Flow<List<Sub>>
    @Insert suspend fun add(s: Sub): Long
    @Delete suspend fun del(s: Sub)
    @Update suspend fun upd(s: Sub)
    @Query("SELECT * FROM Sub WHERE id=:i") suspend fun byId(i: Long): Sub?
    @Query("SELECT * FROM Sub") suspend fun snapshot(): List<Sub>
}

@Database(entities = [Sub::class], version = 2, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): SubDao
    companion object {
        @Volatile private var I: Db? = null
        fun get(c: Context): Db = I ?: synchronized(this) {
            I ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "iptv.db")
                .addMigrations(object : androidx.room.migration.Migration(1, 2) {
                    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) { db.execSQL("ALTER TABLE Sub ADD COLUMN fmt TEXT NOT NULL DEFAULT ''") }
                }).build().also { I = it }
        }
    }
}

/** Passwords are kept in encrypted storage, never in the database. */
object Secure {
    private fun p(c: Context) = EncryptedSharedPreferences.create(
        c, "sec", MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    fun put(c: Context, id: Long, v: String) = p(c).edit().putString("p$id", v).apply()
    fun get(c: Context, id: Long): String = p(c).getString("p$id", "") ?: ""
    fun del(c: Context, id: Long) = p(c).edit().remove("p$id").apply()
}

data class Ch(val name: String, val url: String, val cat: String = "", val logo: String = "")

object Net {
    fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 20000
        return c.inputStream.bufferedReader().use { it.readText() }
    }
    private fun api(s: String, u: String, p: String) = "${s.trimEnd('/')}/player_api.php?username=$u&password=$p"

    /** Returns the expiry as epoch seconds (0 = none). */
    fun xtreamLogin(s: String, u: String, p: String): Long {
        val ui = JSONObject(get(api(s, u, p))).getJSONObject("user_info")
        if (ui.optInt("auth", 0) != 1) throw IllegalStateException("Invalid credentials")
        return ui.optString("exp_date", "").toLongOrNull() ?: 0L
    }
    fun xtreamLive(s: String, u: String, p: String): List<Ch> {
        val a = JSONArray(get(api(s, u, p) + "&action=get_live_streams"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Ch(o.optString("name"), "xt:live/${o.optInt("stream_id")}.m3u8")
        }
    }
    fun m3u(c: Context, u: String): List<Ch> {
        val t = if (u.startsWith("content:")) c.contentResolver.openInputStream(Uri.parse(u))!!.bufferedReader().use { it.readText() } else if (u.startsWith("/")) java.io.File(u).readText() else get(u)
        var n: String? = null
        val r = ArrayList<Ch>()
        for (l in t.lineSequence()) {
            val s = l.trim()
            if (s.startsWith("#EXTINF")) n = s.substringAfterLast(",").ifBlank { "Channel" }
            else if (s.isNotEmpty() && !s.startsWith("#")) { r.add(Ch(n ?: s, s)); n = null }
        }
        return r
    }
}

private fun JSONObject.str(k: String): String { val v = optString(k, ""); return if (v == "null") "" else v }

data class Vod(val id: String, val name: String, val cover: String, val cat: String, val url: String, val rating: String = "", val added: Long = 0)
data class Cata(val cats: Map<String, String>, val items: List<Vod>)
data class LiveData(val cats: Map<String, String>, val items: List<Ch>)
data class Ep(val id: String, val title: String, val season: Int, val num: Int, val url: String)
data class SeriesInfo(val plot: String, val eps: List<Ep>)

/** Xtream movie / series APIs. Stream links are stored as "xt:" paths (no password) and resolved at play time. */
object Xt {
    private fun q(s: String, u: String, p: String, a: String) = "${s.trimEnd('/')}/player_api.php?username=$u&password=$p&action=$a"
    private fun cats(s: String, u: String, p: String, a: String): Map<String, String> {
        val j = JSONArray(Net.get(q(s, u, p, a)))
        return (0 until j.length()).associate { val o = j.getJSONObject(it); o.str("category_id") to o.str("category_name") }
    }
    fun movies(s: String, u: String, p: String): Cata {
        val c = cats(s, u, p, "get_vod_categories")
        val a = JSONArray(Net.get(q(s, u, p, "get_vod_streams")))
        return Cata(c, (0 until a.length()).map {
            val o = a.getJSONObject(it); val id = o.str("stream_id")
            val ext = o.str("container_extension").ifBlank { "mp4" }
            Vod(id, o.str("name"), o.str("stream_icon"), o.str("category_id"), "xt:movie/$id.$ext", o.str("rating"), o.str("added").toLongOrNull() ?: 0L)
        })
    }
    fun seriesList(s: String, u: String, p: String): Cata {
        val c = cats(s, u, p, "get_series_categories")
        val a = JSONArray(Net.get(q(s, u, p, "get_series")))
        return Cata(c, (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Vod(o.str("series_id"), o.str("name"), o.str("cover"), o.str("category_id"), "", o.str("rating"), o.str("last_modified").toLongOrNull() ?: 0L)
        })
    }
    fun live(s: String, u: String, p: String): LiveData {
        val c = cats(s, u, p, "get_live_categories")
        val a = JSONArray(Net.get(q(s, u, p, "get_live_streams")))
        return LiveData(c, (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Ch(o.str("name"), "xt:live/${o.str("stream_id")}.m3u8", o.str("category_id"), o.str("stream_icon"))
        })
    }
    fun m3uLive(c: Context, u: String): LiveData {
        val t = if (u.startsWith("content:")) c.contentResolver.openInputStream(Uri.parse(u))!!.bufferedReader().use { it.readText() } else if (u.startsWith("/")) java.io.File(u).readText() else Net.get(u)
        val gr = Regex("group-title=\"([^\"]*)\""); val lr = Regex("tvg-logo=\"([^\"]*)\"")
        var n: String? = null; var g = ""; var lg = ""
        val out = ArrayList<Ch>()
        for (l in t.lineSequence()) {
            val x = l.trim()
            if (x.startsWith("#EXTINF")) {
                n = x.substringAfterLast(",").ifBlank { "Channel" }
                g = gr.find(x)?.groupValues?.get(1) ?: ""; lg = lr.find(x)?.groupValues?.get(1) ?: ""
            } else if (x.isNotEmpty() && !x.startsWith("#")) { out.add(Ch(n ?: x, x, g, lg)); n = null; g = ""; lg = "" }
        }
        return LiveData(out.map { it.cat }.filter { it.isNotBlank() }.distinct().associateWith { it }, out)
    }
    fun episodes(s: String, u: String, p: String, id: String): List<Ep> = seriesInfo(s, u, p, id).eps
    fun seriesInfo(s: String, u: String, p: String, id: String): SeriesInfo {
        val j = JSONObject(Net.get(q(s, u, p, "get_series_info") + "&series_id=$id"))
        val plot = j.optJSONObject("info")?.str("plot").orEmpty()
        val e = j.optJSONObject("episodes") ?: return SeriesInfo(plot, emptyList())
        val out = ArrayList<Ep>()
        for (k in e.keys()) {
            val a = e.optJSONArray(k) ?: continue
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val ext = o.str("container_extension").ifBlank { "mkv" }
                out.add(Ep(o.str("id"), o.str("title"), k.toIntOrNull() ?: 1, o.optInt("episode_num", i + 1), "xt:series/${o.str("id")}.$ext"))
            }
        }
        return SeriesInfo(plot, out.sortedWith(compareBy({ it.season }, { it.num })))
    }
}

fun resolve(c: Context, s: Sub, u: String): String {
    if (!u.startsWith("xt:")) return u
    val r = u.removePrefix("xt:"); val i = r.indexOf('/')
    var tail = r.substring(i + 1)
    if (r.startsWith("live/") && s.fmt.isNotEmpty()) tail = tail.substringBeforeLast('.') + "." + s.fmt
    return "${s.url.trimEnd('/')}/${r.substring(0, i)}/${s.user}/${Secure.get(c, s.id)}/$tail"
}

@Entity(indices = [Index(value = ["subId", "kind", "itemId"], unique = true)])
data class Fav(@PrimaryKey(autoGenerate = true) val id: Long = 0, val subId: Long, val kind: String, val itemId: String,
               val name: String, val url: String, val cover: String = "")

@Entity data class Recent(@PrimaryKey val rk: String, val subId: Long, val kind: String, val itemId: String,
                          val name: String, val url: String, val cover: String, val ts: Long,
                          val pos: Long = 0, val dur: Long = 0, val parent: String = "")

@Entity data class Dl(@PrimaryKey val id: String, val subId: Long, val kind: String, val grp: String, val title: String,
                      val cover: String, val url: String, val path: String, val status: String,
                      val done: Long = 0, val total: Long = 0, val ts: Long = 0)

@Dao interface StoreDao {
    @Query("SELECT * FROM Fav WHERE subId=:s AND kind=:k ORDER BY id DESC") fun list(s: Long, k: String): Flow<List<Fav>>
    @Query("SELECT itemId FROM Fav WHERE subId=:s AND kind=:k") fun ids(s: Long, k: String): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun add(f: Fav)
    @Query("DELETE FROM Fav WHERE subId=:s AND kind=:k AND itemId=:i") suspend fun del(s: Long, k: String, i: String)
    @Query("SELECT * FROM Recent WHERE subId=:s ORDER BY ts DESC LIMIT 80") fun recent(s: Long): Flow<List<Recent>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addRecent(r: Recent)
    @Query("DELETE FROM Recent WHERE rk=:k") suspend fun delRecent(k: String)
    @Query("SELECT * FROM Recent WHERE rk=:k") suspend fun recentOne(k: String): Recent?
    @Query("UPDATE Recent SET pos=:p, dur=:d WHERE rk=:k") suspend fun setPos(k: String, p: Long, d: Long)
    @Query("SELECT * FROM Dl WHERE subId=:s ORDER BY ts DESC") fun dls(s: Long): Flow<List<Dl>>
    @Query("SELECT * FROM Dl WHERE id=:i") suspend fun dl(i: String): Dl?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putDl(d: Dl)
    @Query("UPDATE Dl SET done=:d, total=:t, status=:st WHERE id=:i") suspend fun prog(i: String, d: Long, t: Long, st: String)
    @Query("UPDATE Dl SET status=:st WHERE id=:i") suspend fun setSt(i: String, st: String)
    @Query("DELETE FROM Dl WHERE id=:i") suspend fun delDl(i: String)
    @Query("UPDATE Dl SET status='paused' WHERE status IN ('running','queued')") suspend fun normalize()
    @Query("SELECT * FROM Dl WHERE status IN ('running','queued')") suspend fun activeDl(): List<Dl>
    @Query("SELECT * FROM Dl WHERE status='paused'") suspend fun pausedDl(): List<Dl>
}

@Database(entities = [Fav::class, Recent::class, Dl::class], version = 4, exportSchema = false)
abstract class Store : RoomDatabase() {
    abstract fun dao(): StoreDao
    companion object {
        @Volatile private var I: Store? = null
        fun get(c: Context): Store = I ?: synchronized(this) {
            I ?: Room.databaseBuilder(c.applicationContext, Store::class.java, "store.db").fallbackToDestructiveMigration().build().also { I = it }
        }
    }
}

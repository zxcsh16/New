package com.iptv.player.ui

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.BackHandler
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.iptv.player.R
import com.iptv.player.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

private fun webEnc(s: String) = URLEncoder.encode(s, "UTF-8")
private fun webGet(url: String): String {
    val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
    c.connectTimeout = 12000; c.readTimeout = 20000
    c.setRequestProperty("User-Agent", "RareIPTV/0.7 (Android; metadata search)")
    c.setRequestProperty("Accept", "application/json")
    return c.inputStream.bufferedReader().use { it.readText() }
}
private data class WebTitle(val id: Int, val type: String, val name: String, val year: String, val poster: String, val overview: String, val rating: Double)
private data class WebEpisode(val season: Int, val number: Int, val name: String, val overview: String, val still: String)
private data class WebSource(val name: String, val url: String, val mode: String)

/** Public metadata catalogues only: TVmaze for series/episodes and Apple Search for films. */
private object WebMetadata {
    fun search(q: String): List<WebTitle> {
        val out = LinkedHashMap<String, WebTitle>()
        val tv = runCatching { JSONArray(webGet("https://api.tvmaze.com/search/shows?q=${webEnc(q)}")) }.getOrDefault(JSONArray())
        for (i in 0 until tv.length()) {
            val show = tv.optJSONObject(i)?.optJSONObject("show") ?: continue
            val id = show.optInt("id"); val name = show.optString("name")
            if (id <= 0 || name.isBlank()) continue
            val image = show.optJSONObject("image")
            val poster = image?.optString("original").orEmpty().ifBlank { image?.optString("medium").orEmpty() }
            val premiered = show.optString("premiered")
            val summary = show.optString("summary").replace(Regex("<[^>]*>"), " ").replace("&amp;", "&").trim()
            val rating = show.optJSONObject("rating")?.optDouble("average", 0.0) ?: 0.0
            out["tv:$id"] = WebTitle(id, "tv", name, premiered.take(4), poster, summary, rating)
        }
        val movies = runCatching { JSONObject(webGet("https://itunes.apple.com/search?term=${webEnc(q)}&entity=movie&limit=30&country=us")).optJSONArray("results") ?: JSONArray() }.getOrDefault(JSONArray())
        for (i in 0 until movies.length()) {
            val o = movies.optJSONObject(i) ?: continue
            val id = o.optInt("trackId"); val name = o.optString("trackName")
            if (id <= 0 || name.isBlank()) continue
            val year = o.optString("releaseDate").take(4)
            val poster = o.optString("artworkUrl100").replace("100x100bb", "600x900bb")
            val overview = o.optString("longDescription").ifBlank { o.optString("shortDescription") }
            out["movie:$id"] = WebTitle(id, "movie", name, year, poster, overview, 0.0)
        }
        return out.values.take(50)
    }
    fun details(t: WebTitle): WebTitle = t
    fun episodes(t: WebTitle): List<WebEpisode> {
        if (t.type != "tv") return emptyList()
        val arr = JSONArray(webGet("https://api.tvmaze.com/shows/${t.id}/episodes"))
        val out = ArrayList<WebEpisode>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val season = e.optInt("season"); val number = e.optInt("number")
            if (season <= 0 || number <= 0) continue
            val image = e.optJSONObject("image")
            val still = image?.optString("original").orEmpty().ifBlank { image?.optString("medium").orEmpty() }
            val overview = e.optString("summary").replace(Regex("<[^>]*>"), " ").replace("&amp;", "&").trim()
            out.add(WebEpisode(season, number, e.optString("name").ifBlank { "Episode $number" }, overview, still))
        }
        return out
    }
}

@Composable fun WebSearchScreen(sub: Sub?, onPlay: (String, String, String, String, String) -> Unit, onOpenSeries: (Vod) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("web_sources", 0) }
    var query by remember { mutableStateOf(prefs.getString("last_query", "") ?: "") }
    var busy by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<WebTitle>>(emptyList()) }
    var selected by remember { mutableStateOf<WebTitle?>(null) }
    var episodes by remember { mutableStateOf<List<WebEpisode>>(emptyList()) }
    var message by remember { mutableStateOf("") }
    var addTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var sourceName by remember { mutableStateOf("") }
    var sourceUrl by remember { mutableStateOf("") }
    var sourceMode by remember { mutableStateOf("auto") }
    var browserUrl by remember { mutableStateOf<String?>(null) }
    var browserTitle by remember { mutableStateOf("") }
    var browserTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    var season by remember { mutableIntStateOf(1) }

    fun sources(key: String): List<WebSource> {
        val a = JSONArray(prefs.getString(key, "[]") ?: "[]")
        return (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { WebSource(it.optString("name"), it.optString("url"), it.optString("mode", "auto")) } }
    }
    fun addSource(key: String, name: String, url: String, mode: String) {
        val a = JSONArray(prefs.getString(key, "[]") ?: "[]")
        a.put(JSONObject().put("name", name).put("url", url).put("mode", mode))
        prefs.edit().putString(key, a.toString()).apply(); refresh++
    }
    fun removeSource(key: String, url: String) {
        val old = JSONArray(prefs.getString(key, "[]") ?: "[]"); val next = JSONArray()
        for (i in 0 until old.length()) { val o = old.optJSONObject(i) ?: continue; if (o.optString("url") != url) next.put(o) }
        prefs.edit().putString(key, next.toString()).apply(); refresh++
    }
    fun playSource(src: WebSource, title: String) {
        val direct = src.mode == "native" || (src.mode == "auto" && Regex("(?i)\\.(m3u8|mp4|mkv|mpd|ts)(\\?|$)").containsMatchIn(src.url))
        if (direct) onPlay(src.url, title, "external", src.url, "") else { browserTarget = null; browserTitle = title; browserUrl = src.url }
    }
    fun search() {
        val q = query.trim(); if (q.length < 2 || busy) return
        busy = true; prefs.edit().putString("last_query", q).apply(); results = emptyList(); selected = null; episodes = emptyList(); message = ""
    }
    fun findOfficial(title: String, key: String) {
        browserTitle = title; browserTarget = key to title
        browserUrl = "https://duckduckgo.com/?q=" + webEnc("$title official streaming Arabic subtitles")
    }
    LaunchedEffect(busy) {
        if (!busy) return@LaunchedEffect
        val q = query.trim()
        try {
            results = withContext(Dispatchers.IO) { WebMetadata.search(q) }
            if (results.isEmpty()) message = ctx.getString(R.string.web_no_results)
        } catch (e: Exception) { message = e.message ?: ctx.getString(R.string.web_search_error) }
        busy = false
    }
    LaunchedEffect(selected?.id, selected?.type) {
        val t = selected ?: return@LaunchedEffect
        episodes = emptyList(); season = 1
        try {
            val full = withContext(Dispatchers.IO) { WebMetadata.details(t) }
            selected = full
            if (t.type == "tv") {
                episodes = withContext(Dispatchers.IO) { WebMetadata.episodes(full) }
                season = episodes.firstOrNull()?.season ?: 1
            }
        } catch (_: Exception) { }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BackBtn({ if (selected != null) { selected = null; episodes = emptyList() } else onBack() })
            Text(stringResource(R.string.web_search_title), fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            Text(stringResource(R.string.web_search_subtitle), fontSize = 10.sp, color = Dim)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true,
                placeholder = { Text(stringResource(R.string.web_search_hint)) }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { search() }), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Acc, unfocusedBorderColor = Dim))
            Fx({ search() }, brush = Grad, pad = 13.dp) { Icon(Icons.Filled.Search, stringResource(R.string.search)) }
        }
        when {
            busy -> Box(Modifier.fillMaxWidth().weight(1f), Alignment.Center) { CircularProgressIndicator(color = Acc) }
            selected != null -> {
                val t = selected!!
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    AsyncImage(t.poster, null, Modifier.fillMaxHeight().weight(.34f).clip(RoundedCornerShape(14.dp)).background(Side), contentScale = ContentScale.Crop)
                    Column(Modifier.weight(.66f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text(t.name, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                        Text("${if (t.type == "movie") stringResource(R.string.web_movie) else stringResource(R.string.web_series)} · ${t.year} · ★ ${"%.1f".format(t.rating)}", color = Acc, fontSize = 11.sp)
                        Text(t.overview.ifBlank { stringResource(R.string.web_no_overview) }, color = Dim, fontSize = 12.sp, maxLines = 5)
                        Text("بيانات المسلسلات: TVmaze · بيانات الأفلام: Apple Search", color = Dim, fontSize = 8.sp)
                        if (t.type == "movie") {
                            val key = "${t.type}_${t.id}"
                            val saved = remember(key, refresh) { sources(key) }
                            Text(stringResource(R.string.web_sources), color = Acc, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            saved.forEach { src -> Row(verticalAlignment = Alignment.CenterVertically) {
                                Fx({ playSource(src, t.name) }, Modifier.weight(1f), pad = 7.dp, onLong = { removeSource(key, src.url) }) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.PlayArrow, null, tint = Ok); Text(src.name, fontSize = 12.sp, modifier = Modifier.weight(1f)); Text(stringResource(R.string.web_play), fontSize = 10.sp, color = Dim) } }
                                Fx({ removeSource(key, src.url) }, pad = 7.dp) { Text("×", color = Err) }
                            } }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Fx({ findOfficial(t.name, key) }, pad = 8.dp) { Icon(Icons.Filled.Search, null); Text(stringResource(R.string.web_find_official), fontSize = 10.sp) }
                                Fx({ addTarget = key to t.name; sourceName = ""; sourceUrl = ""; sourceMode = "auto" }, brush = Grad, pad = 8.dp) { Icon(Icons.Filled.Add, null); Text(stringResource(R.string.web_add_source), fontSize = 11.sp) }
                            }
                        } else {
                            val seasonList = episodes.map { it.season }.distinct().sorted()
                            if (seasonList.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { seasonList.forEach { sn -> Chip("${stringResource(R.string.season)} $sn", season == sn) { season = sn } } }
                            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                items(episodes.filter { it.season == season }) { ep ->
                                    val key = "tv_${t.id}_${ep.season}_${ep.number}"
                                    val saved = remember(key, refresh) { sources(key) }
                                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Side).padding(7.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                            AsyncImage(ep.still.ifBlank { t.poster }, null, Modifier.size(width = 64.dp, height = 42.dp).clip(RoundedCornerShape(5.dp)), contentScale = ContentScale.Crop)
                                            Column(Modifier.weight(1f)) { Text("${ep.number}. ${ep.name}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1); if (ep.overview.isNotBlank()) Text(ep.overview, color = Dim, fontSize = 9.sp, maxLines = 2) }
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Fx({ findOfficial("${t.name} season ${ep.season} episode ${ep.number}", key) }, pad = 6.dp) { Icon(Icons.Filled.Search, null, tint = Acc) }
                                                Fx({ addTarget = key to "${t.name} · S${ep.season}E${ep.number}"; sourceName = ""; sourceUrl = ""; sourceMode = "auto" }, pad = 6.dp) { Icon(Icons.Filled.Add, null, tint = Acc) }
                                            }
                                        }
                                        if (saved.isNotEmpty()) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                                            saved.forEach { src -> Fx({ playSource(src, "${t.name} · ${ep.name}") }, Modifier.weight(1f), pad = 6.dp, onLong = { removeSource(key, src.url) }) { Icon(Icons.Filled.PlayArrow, null, tint = Ok); Text(src.name, fontSize = 10.sp, maxLines = 1) } }
                                        } else Text(stringResource(R.string.web_no_sources), color = Dim, fontSize = 9.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            results.isNotEmpty() -> {
                Text(stringResource(R.string.web_catalogue), color = Acc, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(results) { t -> Fx({ selected = t }, Modifier.fillMaxWidth(), pad = 7.dp) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(t.poster, null, Modifier.size(58.dp, 82.dp).clip(RoundedCornerShape(7.dp)).background(Side), contentScale = ContentScale.Crop)
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) { Text(t.name, fontWeight = FontWeight.Bold, fontSize = 13.sp); Text("${if (t.type == "movie") stringResource(R.string.web_movie) else stringResource(R.string.web_series)} · ${t.year}", color = Dim, fontSize = 10.sp); Text(t.overview, color = Dim, fontSize = 10.sp, maxLines = 2) }
                            Text("★ ${"%.1f".format(t.rating)}", color = Acc, fontSize = 11.sp)
                        }
                    } }
                }
            }
            message.isNotBlank() -> Box(Modifier.fillMaxWidth().weight(1f), Alignment.Center) { Text(message, color = Dim) }
            else -> Box(Modifier.fillMaxWidth().weight(1f), Alignment.Center) { Text(stringResource(R.string.web_intro), color = Dim) }
        }
    }

    val sourceFallback = stringResource(R.string.web_source)
    if (addTarget != null) AlertDialog(onDismissRequest = { addTarget = null }, title = { Text(stringResource(R.string.web_add_source)) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(sourceName, { sourceName = it }, label = { Text(stringResource(R.string.web_source_name)) }, singleLine = true)
            OutlinedTextField(sourceUrl, { sourceUrl = it }, label = { Text(stringResource(R.string.web_source_url)) }, singleLine = true)
            Text(stringResource(R.string.web_playback_method), color = Dim, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { Chip(stringResource(R.string.web_auto), sourceMode == "auto") { sourceMode = "auto" }; Chip(stringResource(R.string.web_native), sourceMode == "native") { sourceMode = "native" }; Chip(stringResource(R.string.web_site), sourceMode == "webview") { sourceMode = "webview" } }
            Text(stringResource(R.string.web_source_note), color = Dim, fontSize = 10.sp)
        } }, confirmButton = { TextButton(onClick = {
            val url = sourceUrl.trim()
            if (url.startsWith("https://") || url.startsWith("http://")) { addSource(addTarget!!.first, sourceName.trim().ifBlank { "$sourceFallback ${sources(addTarget!!.first).size + 1}" }, url, sourceMode); addTarget = null; sourceMode = "auto" }
        }) { Text(stringResource(R.string.save)) } }, dismissButton = { TextButton(onClick = { addTarget = null }) { Text(stringResource(R.string.cancel)) } })

    if (browserUrl != null) WebSourceBrowser(browserUrl!!, browserTitle, onSaveUrl = { page ->
        val target = browserTarget
        if (target != null) { addTarget = target; sourceUrl = page; sourceName = ""; sourceMode = "webview" }
        browserUrl = null
    }) { browserUrl = null }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable private fun WebSourceBrowser(url: String, title: String, onSaveUrl: (String) -> Unit, onClose: () -> Unit) {
    var web by remember { mutableStateOf<WebView?>(null) }
    BackHandler(enabled = web?.canGoBack() == true) { web?.goBack() }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().padding(10.dp).clip(RoundedCornerShape(16.dp)).background(Bg).padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BackBtn(onClose); Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold, maxLines = 1)
                Fx({ web?.url?.takeIf { it.startsWith("https://") || it.startsWith("http://") }?.let(onSaveUrl) }, pad = 7.dp) { Icon(Icons.Filled.Bookmark, null, tint = Acc) }
                Fx({ web?.reload() }, pad = 7.dp) { Icon(Icons.Filled.OpenInBrowser, null) }
            }
            AndroidView(factory = { c -> WebView(c).apply {
                settings.javaScriptEnabled = true; settings.domStorageEnabled = true; settings.mediaPlaybackRequiresUserGesture = false
                webViewClient = WebViewClient(); webChromeClient = WebChromeClient(); loadUrl(url); web = this
            } }, modifier = Modifier.weight(1f).fillMaxWidth(), update = { web = it })
        }
    }
}
